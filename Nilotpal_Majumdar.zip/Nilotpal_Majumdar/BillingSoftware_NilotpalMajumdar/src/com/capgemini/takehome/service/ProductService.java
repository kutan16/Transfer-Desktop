package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;

public class ProductService implements IProductService{
	private IProductDAO productdao = new ProductDAO();
	
	@Override
	public Product getProductDetails(int productCode) throws ProductDetailsNotFoundException {
		Product product = productdao.getProductDetails(productCode);
		if(productdao==null)
			throw new ProductDetailsNotFoundException("Product code is not available"+productCode);
		return product;
	}

	@Override
	public double calculateLineTotal(double productPrice, int quantity) {
		double lineTotal=productPrice*quantity;
		return lineTotal;
	}
	

}
