package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;

public interface IProductService {
	Product getProductDetails(int productCode) throws ProductDetailsNotFoundException;
	double calculateLineTotal(double productPrice, int quantity);
}
