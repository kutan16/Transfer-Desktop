package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.exception.ProductCodeNotValidException;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.exception.WrongQuantityException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;
import com.capgemini.takehome.util.CollectionUtil;

public class Client {

	public static void main(String[] args) throws ProductCodeNotValidException,ProductDetailsNotFoundException, WrongQuantityException{
		IProductService product = new ProductService();
		Scanner sc = new Scanner(System.in);
		System.out.println("********** BILLING SOFTWARE APPLICATION ***********");
		System.out.println("1)  Generate bill by entering product code and quantity ");
		System.out.println("2)  Exit");
		System.out.println("Enter your choice ");
		int choice=sc.nextInt();

		switch(choice) {
		case 1:
			System.out.println("** ENTER PRODUCT DETAILS **");
			System.out.println("Enter the product code : ");
			int code=sc.nextInt();
			if(code<9999) {
				try {
					product.getProductDetails(code);
				}
				catch(ProductDetailsNotFoundException e) {
					e.printStackTrace();
				}
			}
			else
				throw new ProductCodeNotValidException();
			System.out.println("Enter the quantity : ");
			int quantity=sc.nextInt();
			System.out.print(product.getProductDetails(code));
			if(quantity<=0) {
				throw new WrongQuantityException();
			}
			//System.out.print(product.getProductDetails(code));
			System.out.println("Quantity : "+quantity);
			//			System.out.println("Line total : "+product.calculateLineTotal, quantity));

			break;
		case 2:
			System.exit(0);
		default:
			System.out.println("Wrong choice");	
		}
	}

}
