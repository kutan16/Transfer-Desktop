package com.capgemini.takehome.test;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ProductCodeNotValidException;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.util.CollectionUtil;

public class BillingSoftwareTest {
	private static ProductDAO product;
	private static CollectionUtil collection;
	
	@Before
	public void setUpTestEnv() {
		product=new ProductDAO();
	}
	
	@Test()
	public void getProductDetailsForInvalidProductId() throws ProductCodeNotValidException{
		product.getProductDetails(10564);
	}
	
	@Test
	public void getProductDetailsForValidProductId() {
		product.getProductDetails(101);
	}
	
	@AfterClass
	public static void tearDownEnv() {
		product=null;
	}

}
