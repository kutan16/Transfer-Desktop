package com.capgemini.takehome.bean;

public enum Collection {
	Electronics,Toys;
}
