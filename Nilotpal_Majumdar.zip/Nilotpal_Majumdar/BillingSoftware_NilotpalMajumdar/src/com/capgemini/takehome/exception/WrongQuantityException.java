package com.capgemini.takehome.exception;

public class WrongQuantityException extends Exception{

	public WrongQuantityException() {
		super("quantity must be greater than 0 ");
	}

}
