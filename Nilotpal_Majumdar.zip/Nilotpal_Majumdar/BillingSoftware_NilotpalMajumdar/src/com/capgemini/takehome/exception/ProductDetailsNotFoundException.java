package com.capgemini.takehome.exception;

public class ProductDetailsNotFoundException extends Exception{

	public ProductDetailsNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
