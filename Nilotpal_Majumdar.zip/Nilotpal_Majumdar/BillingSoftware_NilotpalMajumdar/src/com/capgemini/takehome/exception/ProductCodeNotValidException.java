package com.capgemini.takehome.exception;

public class ProductCodeNotValidException extends Exception{

	public ProductCodeNotValidException(String string) {
		// TODO Auto-generated constructor stub
	}

	public ProductCodeNotValidException() {
		super("product code must be 4 digit ");
	}

}
