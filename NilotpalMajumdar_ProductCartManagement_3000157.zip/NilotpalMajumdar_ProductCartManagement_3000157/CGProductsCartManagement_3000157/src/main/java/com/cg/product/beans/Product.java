package com.cg.product.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//PRODUCT entity is created. it will be a database table
@Entity
public class Product {
	//generating product id as primary key
	@Id
	private String productId;
	private String productName;
	private String productModel;
	private int productPrice;
	//default constructor
	public Product() {
		super();
	}
	//parameterized constructor
	public Product(String productId, String productName, String productModel, int productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productModel = productModel;
		this.productPrice = productPrice;
	}
	//GETTER SETTER Methods
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
	//TO STRING method to print all
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productModel=" + productModel
				+ ", productPrice=" + productPrice + "]";
	}
	
	
}
