package com.cg.product.services;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.exception.ProductDetailsNotFoundException;
//this is the service layer
public interface IProductService {
	//service layer method to accept product details
	Product acceptProductDetails(Product product);
	//service layer method to update product details
	Product updateProductDetails(String productId,Product product) throws ProductDetailsNotFoundException;
	//service layer method to find a product details
	Product getProductDetails(String productId) throws ProductDetailsNotFoundException;
	//service layer method to find ALL product details
	List<Product>getAllProductDetails();
	//service layer method to remove a product details
	boolean removeProductDetails(String productId);
}
