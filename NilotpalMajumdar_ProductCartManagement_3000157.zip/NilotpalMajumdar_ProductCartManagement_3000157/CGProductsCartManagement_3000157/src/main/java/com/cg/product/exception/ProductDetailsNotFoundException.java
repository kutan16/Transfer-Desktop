package com.cg.product.exception;
//EXCEPTION CLASS FOR PRODUCT DETAILS NOT FOUND
@SuppressWarnings("serial")
public class ProductDetailsNotFoundException extends Exception{

	public ProductDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
