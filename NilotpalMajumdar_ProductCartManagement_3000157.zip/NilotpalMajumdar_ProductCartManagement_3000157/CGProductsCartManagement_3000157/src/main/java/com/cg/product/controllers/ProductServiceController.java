package com.cg.product.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.product.beans.Product;
import com.cg.product.exception.ProductDetailsNotFoundException;
import com.cg.product.services.IProductService;
//Defining the controller through @Controller annotation
@Controller
public class ProductServiceController {
	
	//autowiring a reference of service layer 
	@Autowired
	private IProductService iProductService;
	
	//to accept product details  using POST Request
	@RequestMapping(value={"/acceptProductDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product) throws ProductDetailsNotFoundException{
		product=iProductService.acceptProductDetails(product);
		return new ResponseEntity<>("Product details successfully added for productId  "+product.getProductId(),HttpStatus.OK);
	}
	
	//to find a product detail  using GET Request
	@RequestMapping(value= {"/products/{productId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Product>getProductDetails(@PathVariable(value="productId")String productId)throws ProductDetailsNotFoundException{
		Product product = iProductService.getProductDetails(productId);
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
	
	//to find ALL product details  using GET Request
	@RequestMapping(value={"/products"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetails() {
		return new ResponseEntity<List<Product>>(iProductService.getAllProductDetails(),HttpStatus.OK);
	}
	
	//to delete a product  using DELETE Request
	@RequestMapping(value="/removeProductDetails/{productId}",method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeProductDetails(@PathVariable(value="productId") String productId)throws ProductDetailsNotFoundException{
		iProductService.removeProductDetails(productId);
		return new ResponseEntity<>("Product Details Successfully removed",HttpStatus.OK);
	}
	
	//to update a product using PUT Request
	@RequestMapping(value="/updateProductDetails/{productId}",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeProductDetails(@PathVariable(value="productId") String productId,@ModelAttribute Product product)throws ProductDetailsNotFoundException{
		iProductService.updateProductDetails(productId,product);
		return new ResponseEntity<>("Product Details Successfully Updated  ",HttpStatus.OK);
	}
}
