package com.cg.product.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.product.beans.Product;

public interface IProductRepo extends JpaRepository<Product,String>{
	//DAO layer for the product which uses the JPA REPOSITORY to perform inbuilt CRUD Operations
	//(create read update delete)
}
