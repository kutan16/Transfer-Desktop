package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.dao.IProductRepo;
import com.cg.product.exception.ProductDetailsNotFoundException;
//the component annotation is used for auto detection and class path scanning by the Product Service Controller
@Component("iProductService")
public class ProductServiceImpl implements IProductService{
	
	//reference created for product dao layer
	@Autowired
	IProductRepo iProductRepo;
	
	//service layer implementation method for creating product 
	@Override
	public Product acceptProductDetails(Product product) {
		return iProductRepo.save(product);
	}

	//service layer  implementation method for updating a product
	public Product updateProductDetails(String productId, Product product) throws ProductDetailsNotFoundException{
				removeProductDetails(productId);
				product.setProductId(productId);
		return iProductRepo.save(product);
		
	}

	//service layer  implementation method for finding a product
	@Override
	public Product getProductDetails(String productId) throws ProductDetailsNotFoundException {
		return iProductRepo.findById(productId).orElseThrow(()->new ProductDetailsNotFoundException("Product Details not found for Product ID "+productId));
	}

	//service layer  implementation method for displaying All products
	@Override
	public List<Product> getAllProductDetails() {
		return iProductRepo.findAll();
	}

	//service layer  implementation method for deleting a product
	@Override
	public boolean removeProductDetails(String productId) {
		iProductRepo.deleteById(productId); 
		return true;
	}

}
