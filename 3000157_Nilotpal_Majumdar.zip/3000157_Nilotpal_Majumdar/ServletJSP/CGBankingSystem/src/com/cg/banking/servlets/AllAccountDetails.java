package com.cg.banking.servlets;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/allAccountDetails")
public class AllAccountDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	BankingServices bankingServices;

	@Override
	public void init() throws ServletException {
		bankingServices=new BankingServicesImpl();
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Account> allAccount=bankingServices.getAllAccountDetails();
			request.setAttribute("allAccount", allAccount);
			request.getRequestDispatcher("allAccountDetailsSuccess.jsp").forward(request,response);
		} catch (BankingServicesDownException e) {
			request.getRequestDispatcher("allAccountDetails.jsp").forward(request,response);

		}
	}

@Override
	public void destroy() {
		bankingServices=null;
	}

}