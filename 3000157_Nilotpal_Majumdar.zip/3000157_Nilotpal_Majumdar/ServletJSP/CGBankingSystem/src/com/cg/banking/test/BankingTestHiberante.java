package com.cg.banking.test;
import java.util.LinkedList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.omg.CORBA.TRANSACTION_ROLLEDBACK;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingTestHiberante {
	Account account=new Account();
	AccountDAO acntDAO=new AccountDAOImpl();
	TransactionDAO txnDAO=new TransactionDAOImpl();
private static BankingServices service;
@BeforeClass
public static void setUpTestEnv() {
	service= new BankingServicesImpl();
}
@Before
public void setUpTestData() throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {

	service.openAccount("Savings",10000);
}

@Test(expected= AccountNotFoundException.class)
public void getAccountDetailsForInvalidData()throws InvalidAccountTypeException, 
AccountNotFoundException, BankingServicesDownException{
	service.getAccountDetails(5446);
}
@Test
public void getAccountDetailsForValidData() throws InvalidAccountTypeException, 
BankingServicesDownException, AccountNotFoundException {
	List<Transaction> trans= new LinkedList<Transaction>();
	Account expectedAccount= new Account(1,504,"Savings","Active",10000,trans);
	Account actualAccount= service.getAccountDetails(1);
	Assert.assertEquals(expectedAccount, actualAccount);
}
@Test(expected=AccountNotFoundException.class)
public void testDepositForInvalidData() throws InvalidAccountTypeException, 
AccountNotFoundException, BankingServicesDownException{
	service.getAccountDetails(564);
}
@Test
public void testDepositForValidData() throws InvalidAmountException, AccountNotFoundException,
InvalidAccountTypeException, AccountBlockedException, com.cg.banking.exceptions.AccountNotFoundException, 
BankingServicesDownException{
	int expectedBalance =11000;
    int actualBalance=  (int) service.depositAmount(1,1000);
    Assert.assertEquals(expectedBalance,actualBalance);
}
@Test
public void testWithdrawForValidData() throws InsufficientAmountException, AccountNotFoundException,
InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
	long expectedBalance =(long)service.withdrawAmount(1, 500, 502);
	long actualBalance= (long)service.withdrawAmount(1,0,502);
	Assert.assertEquals(expectedBalance, actualBalance);
}
@Test(expected=AccountNotFoundException.class)
public void testWithdrawForInvalidData() throws AccountNotFoundException, InvalidAccountTypeException,
InvalidAmountException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException, 
AccountNotFoundException, BankingServicesDownException{
	service.withdrawAmount(456, 622, 201);
}
@Test(expected=AccountNotFoundException.class)
public void testFundTransferForInvalidData()throws AccountNotFoundException, InvalidAccountTypeException, 
InvalidAmountException, InvalidPinNumberException, AccountBlockedException, InvalidAccountTypeException, 
InsufficientAmountException, AccountNotFoundException, BankingServicesDownException{
	service.fundTransfer(402, 506, 5000, 208);
}
@Test
public void testfundTransferForvalidData() throws AccountNotFoundException, InvalidAccountTypeException,
InvalidAmountException, InvalidPinNumberException, AccountBlockedException, InvalidAccountTypeException,
InsufficientAmountException,AccountNotFoundException, BankingServicesDownException{
	boolean expectedResponse=service.fundTransfer(1, 1, 500, 505);
	boolean actualResponse= service.fundTransfer(1,1,500,505);
	Assert.assertEquals(expectedResponse, actualResponse);
}
@After
public void tearDownTestData() {
	
}

}