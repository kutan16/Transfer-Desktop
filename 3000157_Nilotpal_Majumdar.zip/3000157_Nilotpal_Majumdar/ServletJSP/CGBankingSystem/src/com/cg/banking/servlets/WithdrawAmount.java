package com.cg.banking.servlets;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/withdraw")
public class WithdrawAmount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BankingServices bankServices;
	
	@Override
	public void init() throws ServletException {
		bankServices=new BankingServicesImpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
			try {
				int finalBalance = (int) bankServices.withdrawAmount(accountNumber, amount, pinNumber);
				request.setAttribute("finalBalance", finalBalance);
				request.getRequestDispatcher("withdrawSuccess.jsp").forward(request, response);
			} catch (InsufficientAmountException e) {
				request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			} catch (AccountNotFoundException e) {
				request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			} catch (InvalidPinNumberException e) {
				request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			} catch (BankingServicesDownException e) {
				request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			} catch (AccountBlockedException e) {
				request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			}
			
		
	}
	
	   
    @Override
	public void destroy() {
		bankServices=null;
	}
}
