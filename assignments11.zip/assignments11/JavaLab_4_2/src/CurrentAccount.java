
public class CurrentAccount extends Account 
{
	double overdraftLimit=3500;
	
	@Override
	public void withdraw(double amount)
	{
		if(amount>overdraftLimit)
			System.out.println("Overdraft limit reached");
		else
		{
			balance=balance-amount;
			System.out.println(balance);
		}
	}
}
