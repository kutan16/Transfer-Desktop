
public class SavingsAccount extends Account 
{
	final double minimumBalance=500;
	
	@Override
	public void withdraw(double amount)
	{
		if(balance<minimumBalance)
			System.out.println("Minimum balance not maintained");
		else if(amount>balance)
		{
			System.out.println("withdraw amount exceeding balance");
		}
		else
		{
			balance=balance-amount;
			System.out.println(balance);
		}
	}
}
