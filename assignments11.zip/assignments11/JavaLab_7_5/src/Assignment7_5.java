import java.util.*; 
  
public class Assignment7_5 
{ 
    public static void main(String[] args) 
    { 
 
        ArrayList<String> al = new ArrayList<String>(); 
        al.add("General Kenobi"); 
        al.add("Your are a "); 
        al.add("One"); 
        al.add("Bold"); 
        al.add("Hello There"); 
        Collections.sort(al);  
        System.out.println("List after the use of" + " Collection.sort() :\n" + al); 
    } 
} 