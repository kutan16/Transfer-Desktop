
public class Person
{
	public static void main(String args[]) 
	{
		PersonTest ob = new PersonTest("Nilotpal","Majumdar",'M',1234567890);
		System.out.println("Person Details"+"\n"+"________________");
		System.out.println("First Name = "+ob.getFirstName()+"\n"+"Last Name = "+ob.getLastName()+"\n"+"Gender = "+ob.getGender()+"\n"+"Phone = "+ob.getPhone());
	}
}