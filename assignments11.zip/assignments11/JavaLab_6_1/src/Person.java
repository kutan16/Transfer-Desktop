
public class Person 
{
	private String firstname,lastname;
	private char gender;
	Person() 
	{
		firstname="";
		lastname="";
		gender='\0';
	}
	Person(String f,String l,char g) 
	{
		firstname=f;
		lastname=l;
		gender=g;
	}
	
	public String getFirstName()//throws NameNotValidException
	{
		try
		{
			if(firstname=="")
			{
				throw new NameNotValidException();
			}
		}
		catch(NameNotValidException e)
		{
			System.out.println(e);
		}
		return firstname;
	}
	public void setFirstName(String k) 
	{
		firstname=k;
	}
	
	public String getLastName() 
	{
		try
		{
			if(lastname=="")
			{
				throw new NameNotValidException();
			}
		}
		catch(NameNotValidException e)
		{
			System.out.println(e);
		}
		return lastname;
	}
	public void setLastName(String k)
	{
		lastname = k;
	}
	
	public char getGender() 
	{
		return gender;
	}
	public void setGender(char k) 
	{
		gender=k;
	}
	
}