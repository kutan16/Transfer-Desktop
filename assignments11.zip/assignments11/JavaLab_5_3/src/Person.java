
public class Person extends Account
{
	String name;
	float age;
	
	Person(int accNum, int i, Person s)
	{
		name="";
		age=0.0f;
	}
	Person(String name,float age)
	{
		this.name=name;
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	@Override
	public void withdraw(double amount) {
		if((balance-amount)<0)
			System.out.println("Low account balance ");
		else
		{
			balance=balance-amount;
			System.out.println(balance);
		}
		
	}
	
}
