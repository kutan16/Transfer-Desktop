package com.cg.eis.exception;
import com.cg.eis.*;
public class EmployeeException extends Exception
{
	public EmployeeException()
	{
		super("salray is way too low ");
	}
}
