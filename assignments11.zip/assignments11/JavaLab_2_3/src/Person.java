
public class Person 
{
	private String firstname,lastname;
	private char gender;
	Person() 
	{
		firstname="";
		lastname="";
		gender='\0';
	}
	Person(String f,String l,char g) 
	{
		firstname=f;
		lastname=l;
		gender=g;
	}
	
	public String getFirstName() 
	{
		return firstname;
	}
	public void setFirstName(String k) 
	{
		firstname=k;
	}
	
	public String getLastName() 
	{
		return lastname;
	}
	public void setLastName(String k)
	{
		lastname=k;
	}
	
	public char getGender() 
	{
		return gender;
	}
	public void setGender(char k) 
	{
		gender=k;
	}
	
}