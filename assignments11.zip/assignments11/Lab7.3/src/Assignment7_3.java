import java.util.Arrays;
import java.util.List;


public class Assignment7_3 {
	public static void removeAll(List<String> list1, List<String> list2) {
	    while (list1.contains(list2)) {
	        list1.remove(list2);
	    }
	}
	
	public static List<String> removeElements(List<String> list1, List<String> list2)
	{
		removeAll(list1, list2);
		return list1;
	}

	public static void main(String[] args) {

		List<String> list1 = Arrays.asList("sup1");
		List<String> list2 = Arrays.asList("su");
		removeElements(list1, list2);
		System.out.println(list1);

	}

}
