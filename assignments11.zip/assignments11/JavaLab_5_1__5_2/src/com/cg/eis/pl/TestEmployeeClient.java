package com.cg.eis.pl;
import java.util.*;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Insurance;
import com.cg.eis.service.ServiceSystem;

public class TestEmployeeClient 
{
	public static void main(String[] args) 
	{
		int id;
		int choice;
		String name;
		double salary;
		Designation designation = null;
		Insurance ischeme;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the nao. of employee : ");
		int n=sc.nextInt();
		ServiceSystem emp=new ServiceSystem(n);
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the id : ");
			id=sc.nextInt();
			System.out.println("Enter Employee name : ");
			name=sc.next();
			System.out.println("Enter the salary : ");
			salary=sc.nextDouble();
			System.out.println("Enter the Designation : ");
			System.out.println("------choice------");
			System.out.println("1. SystemAssociate \n 2. Programmer \n 3. Manager \n 4. Clerk");
			System.out.println("Enter your choice : ");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				designation=Designation.SystemAssociate;
				break;
			case 2:
				designation=Designation.Programmer;
				break;
			case 3:
				designation=Designation.Manager;
				break;
			case 4:
				designation=Designation.Clerk;
				break;
			default:
				System.out.println("Enter correct choice");
			}
			ischeme=emp.showInsuranceSchemes(id,salary,designation);
			emp.addEmployeeDetails(id, name, salary, designation, ischeme);
		}
		System.out.println("Employee Details are : ");
		for(int i=0;i<n;i++)
		{
			System.out.println(emp.dispEmployeeDetails(i));
		}
		sc.close();	
	}
}
