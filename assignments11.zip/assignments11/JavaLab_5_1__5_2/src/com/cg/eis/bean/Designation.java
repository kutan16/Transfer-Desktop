package com.cg.eis.bean;

public enum Designation 
{
	SystemAssociate,Programmer,Manager,Clerk;
}
