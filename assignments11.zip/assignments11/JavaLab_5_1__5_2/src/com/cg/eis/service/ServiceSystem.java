package com.cg.eis.service;
import com.cg.eis.bean.*;
//import com.cg.eis.bean.Employee;
//import com.cg.eis.bean.Insurance;

public class ServiceSystem implements EmployeeService
{
	private Employee empList[];
	public ServiceSystem(int nOfEmp)
	{
		this.empList=new Employee[nOfEmp];
	}
	
	@Override
	public void addEmployeeDetails(int id,String name,double salary,Designation designation,Insurance insuranceScheme)
	{
		if(id>0 && id<this.empList.length)
		{
			this.empList[id]=new Employee(id,name,salary,designation,insuranceScheme);
		}
	}
	
	@Override
	public Insurance showInsuranceSchemes(int id,double salary,Designation designation)
	{
		if(id>0 && id<this.empList.length)
		{
			if(salary>=40000 && designation==Designation.Manager)
			{
				return Insurance.SchemeA;
			}
			else if(salary>=20000 && salary<40000 && designation==Designation.Programmer)
			{
				return Insurance.SchemeB;
			}
			else if(salary>5000 && salary<20000 && designation==Designation.SystemAssociate)
			{
				return Insurance.SchemeC;
			}
			else if(salary<5000 && designation==Designation.Clerk)
			{
				return Insurance.NoScheme;
			}
		}
		return null;
	}
	
	@Override
	public String dispEmployeeDetails(int id)
	{
		if(id>0 && id<this.empList.length)
			return this.empList[id].toString();
		else
			return null;
	}
}
