interface FuncInterface 
{ 
	void abstractFun(double x,double y); 
	default void normalFun() 
	{ 
		System.out.println("Hello"); 
	} 
} 