import java.util.*;
public class PositiveString 
{
	public static Boolean chararr1(String str)
	{
		char newStr[]=str.toCharArray();
		char previous='\u0000';
		for(char current : newStr)
		{
			if(current < previous)
				return false;
				previous = current;
		}
		return true;
	}
	public static void main(String args[])
	{
		String str=null;
		System.out.println("Enter a String : ");
		Scanner sc=new Scanner(System.in);
		str=sc.next();
		if(chararr1(str)==true)
			System.out.println("Positive");
		else
			System.out.println("Negative");
	}
}
