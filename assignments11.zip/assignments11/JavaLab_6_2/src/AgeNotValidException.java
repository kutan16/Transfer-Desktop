
@SuppressWarnings("serial")
public class AgeNotValidException extends Exception
{
	public AgeNotValidException()
	{
		super("age is not valid");
	}
}
