import java.util.Arrays;
public class Assignment7_1 {
	
	public static int reverse(int k)
	{
		int num=k, rev=0;
		while(num != 0)
	      {
	          rev = rev * 10;
	          rev = rev + num%10;
	          num = num/10;
	      }
		return rev;
	}
	
	public static void getSorted(int a[])
	{
		int n = a.length;
		int[] b = new int[n]; 
        int j = n; 
        for (int i = 0; i < n; i++) { 
        	a[i]=reverse(a[i]);
            b[j - 1] = a[i]; 
            j = j - 1;
        }
        Arrays.sort(a);
	}

	public static void main(String[] args) {
		
		int[] a = {10,25,48,18,46};
		getSorted(a);
		int n = a.length;
		for (int k = 0; k < n; k++) { 
            System.out.print(a[k]+" ");
		

	}

}
}
