import java.io.*;
public class Assignment9_2 
{ 
  public static void main(String[] args)throws Exception {
  FileReader fr = 
	      new FileReader("D:\\\\file1.txt"); 
	  
	    int i; 
	    while ((i=fr.read()) != -1)
	    	if(i%2==0 && i!=44)
	      System.out.print((char) i+" ");
} }