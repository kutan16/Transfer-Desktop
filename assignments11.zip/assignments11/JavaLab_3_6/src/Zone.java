import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
public class Zone 
{
	public static void printTime(String str)
	{
		Date today = new Date();
		DateFormat df = new SimpleDateFormat("dd-MM-yy HH:mm:SS z");
		df.setTimeZone(TimeZone.getTimeZone(str));
		String IST = df.format(today);
		System.out.println("Date in Timezone : "+IST);
	}
	public static void main(String args[])
	{
		System.out.println("Enter time zone id : ");
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		printTime(str);
	}
}
